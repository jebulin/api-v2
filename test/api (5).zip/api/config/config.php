<?php

$hostname = 'localhost';
$username = "root";
$password = "root";
$database = 'lorry_app';

$conn = mysqli_connect($hostname, $username, $password, $database);

if(!$conn){
    die('Connection failes: '. mysqli_connect_error());
}

?>
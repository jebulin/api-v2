<?php
class Approval{
    const APPROVED = 1;
    const PENDING = 2;
    const DENIED = 3;
}

?>
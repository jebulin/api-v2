<?php
class Roles{
    const SUPER_ADMIN = 1;
    const ADMIN = 2;
    const STANDARD_USER = 3;
}

?>
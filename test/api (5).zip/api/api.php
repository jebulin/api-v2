<?php
session_start();
require_once 'config/config.php';
require_once 'service/users.php';
require_once 'service/news-letters.php';
require_once 'service/reports.php';
require_once 'service/members.php';
require_once 'middleware/authorization.middleware.php';
// require_once 'service/google.php';
require_once 'service/generate_idcard.php';

// Use the authorize function to check if the request is authorized
authorize();

$userObj = new User($conn);
$newsLetterObj = new NewsLetter($conn);
$reportObj = new Report($conn);
$memObj = new Member($conn);
// $google = new GoogleDriveUpload($conn);
$idCard = new IDCard($conn);

$method = $_SERVER['REQUEST_METHOD'];

$endpoint = $_SERVER['PATH_INFO'];

header('Content-Type: application/json');

if (isset($_SERVER['HTTP_ORIGIN'])) {
    // Dynamically set the Access-Control-Allow-Origin header
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // Cache for 1 day
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, DELETE, PUT");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
}

// Specify which request methods are allowed
header('Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS');

switch ($method) {
    case 'GET':
        switch ($endpoint) {
            case '/user/get/all':
                $users = $userObj->getAllUsers();
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/get/rejected-users':
                $users = $userObj->getAllDeletedUsers();
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/get/approved-users':
                $users = $userObj->getAllApprovedUsers();
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/get/approval-pending-users':
                $users = $userObj->getAllApprovalPendingUsers();
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/get/declined-users':
                $users = $userObj->getAllDeclinedUsers();
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/get/approved-and-declined-users':
                $users = $userObj->getAllApprovedAndDeclinedUsers();
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/verify-email':
                $users = $userObj->verifyEmail();
                http_response_code(current($users));
                echo json_encode($users);
                break;
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        switch ($endpoint) {
            case '/user/get':
                $users = $userObj->getUser($data);
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/create':
                $users = $userObj->createUser($data);
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/change-password':
                $users = $userObj->changePassword($data);
                http_response_code(current($users));
                echo json_encode($users);
                break;
            case '/user/approval-status': //approve/ disapprove
                $users = $userObj->approvalStatus($data);
                http_response_code(current($users));
                echo json_encode($users);
                break;


            case '/members/search':
                $members = $memObj->search($data);
                http_response_code(current($members));
                echo json_encode($members);
                break;


                ////newsletters
            case '/news-letters/create':
                $newLetter = $newsLetterObj->createNewsLetter($data);
                http_response_code(current($newLetter));
                echo json_encode($newLetter);
                break;
            case '/news-letters/get/all':
                $newsLetters = $newsLetterObj->getAllNewsLetters($data);
                http_response_code(current($newsLetters));
                echo json_encode($newsLetters);
                break;
            case '/news-letters/get/one':
                $newLetter = $newsLetterObj->getOneNewsLetter($data);
                http_response_code(current($newLetter));
                echo json_encode($newLetter);
                break;
            case '/news-letters/update':
                $newLetter = $newsLetterObj->updateNewsLetter($data);
                http_response_code(current($newLetter));
                echo json_encode($newLetter);
                break;


                ///reports
            case '/reports/create':
                $reports = $reportObj->createReport($data);
                http_response_code(current($reports));
                echo json_encode($reports);
                break;
            case '/reports/get/all':
                $reports = $reportObj->getAllReports($data);
                http_response_code(current($reports));
                echo json_encode($reports);
                break;
            case '/reports/get/one':
                $report = $reportObj->getOneReport($data);
                http_response_code(current($report));
                echo json_encode($report);
                break;
            case '/reports/update':
                $report = $reportObj->updateReport($data);
                http_response_code(current($report));
                echo json_encode($report);
                break;


            case '/generate/id-card':
                $id = $idCard->generateIdCard($data);
                http_response_code(current($id));
                echo json_encode($id);
                break;
        }
        break;

    default:
        $default = array("http" => 404, "msg" => "path not found", "status" => false);
        http_response_code(current($default));
        echo json_encode($default);
        break;
}

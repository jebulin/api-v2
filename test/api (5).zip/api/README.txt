Before starting the app 

=> check config file and set the database, password and root

=> api.php, auth.php and general.php have the routes

=> states, districts and sub-districts in 